import pickle
import os

pkl_filename = "pickle_model.pkl"
absolute_path = os.path.dirname(__file__)
print(absolute_path)

with open(os.path.join(absolute_path,pkl_filename), 'rb') as file:
    pickle_model = pickle.load(file)

def predict(x_val):
    y_predict = pickle_model.predict(x_val)
    return y_predict