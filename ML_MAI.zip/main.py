from flask import Flask, request, render_template
from ml import predict
 
app = Flask(__name__)
keys = ["q"+str(i) for i in range(1,13)]
values = [[0 for i in keys]]
result_dict = {
    1: "Решительный",
    2: "Нерешительный",
    3: "Импульсивный"
}

# @app.route('/form', methods=['POST', 'GET'])
@app.route('/',  methods=['POST', 'GET'])
def form():
    error = None
    result = None
    success = False
    if request.method == 'POST':

        try:
            for i in range(len(keys)):
                values[0][i] = int(request.form[keys[i]])
            success = True
        except Exception:
            error = "Не весь опрос выполнен"
            success = False
            result = None

        if success:
            error = None

            result = result_dict[predict(values)[0]]

    return render_template("index.html", error = error, result = result)

if __name__ == '__main__':
    app.run(debug=True)
